
<style lang="scss">
  @import "../assets/css/mixin";
  .siderMenu{
    padding: 5px 0 3px 0;

    .el-tabs{
      width: 100%;
    }
    .el-aside{
      background-color: transparent !important;
      width: 225px !important;

      .el-tree{
        height: 344px;
        @include showScrollbarY;
      }

    }
    .el-tree{
      background-color: transparent;
      color:#000;
      font-size: 12px;
      margin-left: -7px;
      .el-tree-node__expand-icon{
        color: #999;
        font-size: 13px;
      }
    }
    .el-tree--highlight-current .el-tree-node:hover>.el-tree-node__content {
      background-color: transparent;
    }
    .el-tree--highlight-current  .el-tree-node.is-current>.el-tree-node__content {
      background-color: transparent;
    }
    .el-tree--highlight-current  .el-tree-node.is-focusable>.el-tree-node__content {
      background-color: transparent;
    }
    .el-tree--highlight-current .el-tree-node:hover>.el-tree-node__content {
      color: $highlightColor;
      .el-tree-node__expand-icon{
        color: $highlightColor;
      }
    }
    .custom-tree-node{
      @include textOmit();
      span{
        @include textOmit;
        max-width: 100%;
      }

      padding-top: 5px;
      padding-bottom: 5px;
      display: inline-block;
    }
    .el-tree-node__content[style="padding-left: 36px"]{
      .el-tree-node__expand-icon{
        display: none;
      }
      .custom-tree-node{
        margin-left: 7px;
      }
      .custom-tree-node +.is-leaf{
        display: none;
      }

    }
  }

</style>
<template>
  <div class="siderMenu" v-if="data">
    <el-aside width="200px" style="background-color: rgb(238, 241, 246)">
      <div class="custom-tree-container">
        <!--:default-expanded-keys="[data.themeColors[0].children[0].id]"-->
        <div class="block">
          <el-tree
            ref="tree"
            :data="data"
            node-key="id"
            :expand-on-click-node=false
            :default-expand-all=true
            accordion
            :highlight-current=true
            @node-click="handleNodeClick">
              <span :level="node.level" class="custom-tree-node" slot-scope="{ node, data }">
                <span :title=" node.label||'color theme'">{{ node.label||'color theme' }}</span>
               <!-- <span>
                  <el-button
                    type="text"
                    size="mini"
                    @click="() => append(data)">
                    Add
                  </el-button>
                  <el-button
                    type="text"
                    size="mini"
                    @click="() => remove(node, data)">
                    Del
                  </el-button>
                </span>-->
              </span>
          </el-tree>
        </div>
      </div>
    </el-aside>
  </div>
</template>

<script>
  export default {
    name: "siderMenu",
    props:['data'],
    computed:{

    },
    methods:{
      handleNodeClick(data,ev) {
        this.$emit('handleNodeClick',data,ev);
      },
      append(data) {
        const newChild = {id: id++, label: 'testtest', children: []};
        if (!data.children) {
          this.$set(data, 'children', []);
        }
        data.children.push(newChild);
      },

      remove(node, data) {
        const parent = node.parent;
        const children = parent.data.children || parent.data;
        const index = children.findIndex(d => d.id === data.id);
        children.splice(index, 1);
      },
    }
  }
</script>





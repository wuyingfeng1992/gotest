<template>
  <div class="editThemeColor">
    <i class="returnIcon"></i>&nbsp;&nbsp;&nbsp;编辑基础颜色
    <hr />
    <p class="fontStyle">名称</p>
    <el-input  placeholder="emui_functional_red" v-model="input1" :disabled="true"></el-input>
    <p class="fontStyle">色值</p>
    <div style="display: flex">
      <el-input  placeholder="#CC0066" v-model="input1"></el-input>
      <el-color-picker id="colorPicker" v-model="colorValue" :predefine="predefineColors" @active-change="selectColor()"></el-color-picker>
    </div>
    <p class="fontStyle">描述</p>
    <el-input type="textarea" :autosize="{ minRows: 2, maxRows: 4}" placeholder="请输入描述..." v-model="textarea3">
    </el-input>
    <el-checkbox v-model="checked">同步至其他品牌Light主题</el-checkbox>
    <div>
      <el-button>取消</el-button>
      <el-button type="primary">保存</el-button>
    </div>
  </div>
</template>

<script>
  export default {
    name: "editThemeColor",
    methods:{
      selectColor:function (){
        alert(this.$("#colorPicker"));
      }
    },
    data() {
      return {
        colorValue: '#409EFF',
        predefineColors: [
          '#ff4500',
          '#ff8c00',
          '#ffd700',
          '#90ee90',
          '#00ced1',
          '#1e90ff',
          '#c71585',
          'rgba(255, 69, 0, 0.68)',
          'rgb(255, 120, 0)',
          'hsv(51, 100, 98)',
          'hsva(120, 40, 94, 0.5)',
          'hsl(181, 100%, 37%)',
          'hsla(209, 100%, 56%, 0.73)',
          '#c7158577'
        ],
        checked:true
      }
    }
  }
</script>

<style lang="scss">
  @import "../assets/css/mixin";
  .editThemeColor{
    padding-top: 30px;
    padding-left: 30px;
    .returnIcon{
      @include icon(16px,11px,'../assets/image/ic_return.png');
    }
    .fontStyle {
      font-size: 12px;
      color: #000000;
      letter-spacing: 0;
    }
  }
</style>


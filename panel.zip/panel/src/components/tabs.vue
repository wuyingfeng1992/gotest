<template>
  <!--computed的效果跟activeName有类似的效果-->
  <el-tabs v-model="activeName" @tab-click="handleClick" >
    <el-tab-pane v-for="item in tabsInfo" :label="item.value" :name="item.name" :key="item.name">
      <keep-alive>
        <tabCon :is="item.label" :itemInfo="item" keep-active  @tabChange="getActiveName"></tabCon>
      </keep-alive>
    </el-tab-pane>
  </el-tabs>
</template>

<script>
  import login from './login'
  //import register from './register'
  export default {
    components: {
      login,
      //   register
    },
    data() {
      return {
        activeName: this.getActiveName()
      };
    },

    methods: {
      handleClick(tab, event) {
        console.log(tab,'毛病')
        /* console.log(tab, event);*/
      },
      getActiveName: function (name) {
        if (!name) name = this.tabsInfo[0].name;
        this.activeName=name;
        return name;
      }
    },

    props: ['tabsInfo']
  };
</script>

<style scoped>

</style>

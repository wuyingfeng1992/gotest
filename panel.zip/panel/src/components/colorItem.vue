<style lang="scss">
  @import "../assets/css/mixin";

  .colorItem {
    margin: 10px;
    width: calc((100% - 80px)/4);
    flex: none;
    position: relative;

    .colorView {
      height: 100px;
      background-color: #007DFF;
      border: 1px solid #E8E8E8;
      border-radius: 6px;
    }

    .colorValue {
      font-size: 12px;
      color: #000000;
      width: calc(100% - 18px);
      @include textOmit;
    }

    .remarks {
      opacity: 0.3;
      margin-top: 2px;
      font-size: 10px;
      color: #000000;
      @include textOmit;

    }

    .editInfoIcon {
      @include icon(14px, 14px, '../assets/image/ic_more.png');
      position: absolute;
      right: 0px;
      bottom: 0px;
      cursor:pointer;
    }
    .description{
      position: relative;
    }
    .descriptionInfo{
      position: relative;
    }
  }
  .editItem{
    color: $highlightColor;
    cursor: pointer;
    .icon{
      margin-right: 10px;
      margin-left: 2px;
      font-size: 14px;
    }

  }
  .el-tooltip__popper{
    &.is-light{
      border:1px solid #fff;
      box-shadow: 0 2px 6px 0 rgba(0,0,0,0.14);
      border-radius: 6px;
    }
  }
  .el-tooltip__popper[x-placement^=left] .popper__arrow::after{
    border-left-color: #fff;
    content: "\E60E";
    text-shadow: 0px 0px 0px rgba(0,0,0,0.26);
  }
  .el-tooltip__popper[x-placement^=right] .popper__arrow::after{
    border-right-color: #fff;
  }
  .el-tooltip__popper.is-light[x-placement^=right] .popper__arrow{
    border-right-color: #fff;
  }

  .el-tooltip__popper.is-light[x-placement^=left] .popper__arrow{
    border-left-color: #fff;
  }

  .el-tooltip__popper[x-placement^=left] .popper__arrow::after {
    border-left-color: #fff;
    content: "\E60E";
    text-shadow: 0px 0px 0px rgba(0, 0, 0, 0.26);
    vertical-align: 10px;
    vertical-align: -20px;
    position: relative;
    top: -14px;
    left: -12px;
  }
  .el-tooltip__popper.is-light[x-placement^=left] .popper__arrow {
    color: #fff;
    font-size: 17px;
    font-family: element-icons!important;
    speak: none;
    font-style: normal;
    font-weight: 400;
    font-variant: normal;
    text-transform: none;
    line-height: 1;
    vertical-align: baseline;
    display: inline-block;
    -webkit-font-smoothing: antialiased;
  }

  .el-tooltip__popper[x-placement^=left] .popper__arrow::after {
    border-left-color: #fff;
    content: "\E60E";
    text-shadow: 2px 1px 2px rgba(0, 0, 0, 0.15);
    vertical-align: 10px;
    vertical-align: -20px;
    position: relative;
    top: -14px;
    left: -11px;
  }

  .el-tooltip__popper[x-placement^=right] .popper__arrow::after {
    border-left-color: #fff;
    content: "\E60A";
    text-shadow: -1px 0px 1px rgba(1px, 0, 0, 0.18);
    vertical-align: 10px;
    vertical-align: -20px;
    position: relative;
    top: -14px;
    left: -6px;
  }
  .el-tooltip__popper.is-light[x-placement^=right] .popper__arrow {
    color: #fff;
    font-size: 17px;
    font-family: element-icons!important;
    speak: none;
    font-style: normal;
    font-weight: 400;
    font-variant: normal;
    text-transform: none;
    line-height: 1;
    vertical-align: baseline;
    display: inline-block;
    -webkit-font-smoothing: antialiased;
  }

</style>
<template>
  <li class="colorItem">
    <div class="colorView" :style="{backgroundColor:item.realValue || item.colorValue}"></div>
    <div class="descriptionInfo">
      <div class="description">
        <p class="colorValue" style="padding-top: 7px;">
          {{item.attrName||item.colorName}}
        </p>
        <el-tooltip content="Right Center 提示文字" placement="right" effect="light">
          <i class="editInfoIcon"> </i>
          <div slot="content">
            <div class="editItem editColorInfo" @click="editColorAccess(item.id);">
              <i class="icon el-icon-edit"></i>
              <span class=" text">编辑</span>
            </div>
          </div>
        </el-tooltip>
      </div>
      <p class="remarks" :title="item.remark">
        {{item.remark||'在这里输入描述'}}
      </p>
    </div>


  </li>

</template>

<script>
  import {mapMutations,mapState} from "vuex";
  export default {
    methods: {
      editColorAccess: function (colorInfo) {
        this.setEditColorState(true)
      },
      ...mapMutations(
        {'setEditColorState':"SET_EDITCOLOR_STATE"}
      )
    },
    props: ["item"],
    components: {

    },
    /*computed:{
      ...mapState([
        "editColorState",
      ])
    }*/
  }
</script>



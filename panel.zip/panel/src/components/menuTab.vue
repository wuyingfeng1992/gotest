<style lang="scss">
  @import "../assets/css/mixin";

  .menuTab {
    display: flex;

    .el-tabs__header {
      margin-bottom: 10px;
    }

    .siderMenuWrap {
      flex: none;
      width: $siderWidth;
      background-color: $siderBg;
      padding: 10px;
    }

    .el-tabs__nav-wrap {
      margin: 0 10px;

      &:after {
        background-color: transparent;
      }
    }

    .el-tabs__nav {
      width: 100%;

      .el-tabs__item {
        width: 50%;
        text-align: center;
        height: 32px;
        line-height: 32px;
        font-size: 12px;
        color: #000;

        &:hover {
          color: $highlightColor;
        }

        &.is-active {
          color: $highlightColor;
        }

        /*$highlightColor*/
      }

      .el-tabs__active-bar {
        background-color: $highlightColor;
      }
    }
  }

</style>

<template>
  <div class="menuTab">
    <!--{{JSON.stringify(data)}}-->
    <div class="siderMenuWrap">
      <el-tabs v-model="activeName"
               @tab-click="handleClick"
               tab-position="top"
               tab-width="50%"
      >
        <el-tab-pane label="基础" name="systemColors"></el-tab-pane>
        <el-tab-pane label="场景" name="themeColors"></el-tab-pane>
      </el-tabs>
      <menuSearch></menuSearch>
      <siderMenu v-if="getCurThemeColorCategoryData" :data="getCurThemeColorCategoryData"
                 @handleNodeClick="handleNodeClick"></siderMenu>
      <div class="openSketchFileDiv">
        <el-button class="opSketchBtn"><i class="sketchIcon"></i>
          <label class="textLabel">打开控件库sketch文件</label>
        </el-button>
      </div>

    </div>

    <menuContent v-if="getCurThemeColorGroupData"
                 :data="getCurThemeColorGroupData">

    </menuContent>
  </div>
</template>

<script>
  import menuContent from '@components/menuContent'
  import menuSearch from '@components/menuSearch'
  import siderMenu from '@components/siderMenu'
  import {mapGetters, mapActions} from 'vuex';

  let flag = true;
  let flag2 = true;
  export default {
    name: "menuTab",
    data() {
      return {
        activeName: 'systemColors',
        curThemeColorGroupData: null,
        curThemeColorCategoryData: null,
      };
    },
    methods: {
      handleClick(tab, event) {
        console.log(tab, event, 'ddd反反复复');
        let name = tab.name;
        this.curThemeColorCategoryData = this.getThemeAttrColor[name];
        this.curThemeColorGroupData = this.curThemeColorCategoryData[0].children[0]
      },
      handleNodeClick(data, ev) {
        console.log(data, ev);
        if (ev.level == 2) {
          this.curThemeColorGroupData = data;
        } else if (ev.level == 1) {
          this.curThemeColorGroupData = data.children[0];
        }
      },
      ...mapActions(['getThemeAttrColorAction']),
    },
    //beforCreate不能拿到methods
    created() {
      this.getThemeAttrColorAction();
    },

    computed: {
      ...mapGetters([
        'getThemeAttrColor',
      ]),
      getCurThemeColorCategoryData: function () {
        return this.curThemeColorCategoryData;
      },
      getCurThemeColorGroupData: function () {
        return this.curThemeColorGroupData;
      },

    },
    watch: {
      getThemeAttrColor(val) {
        if (flag) {
          this.curThemeColorCategoryData = this.getThemeAttrColor.systemColors;
          this.curThemeColorGroupData = this.curThemeColorCategoryData[0].children[0]
          console.log(this.curThemeColorGroupData)
          flag = false
        }
      }
    },

    props: ['data'],
    components: {
      menuContent,
      menuSearch,
      siderMenu,
    }
  }
</script>


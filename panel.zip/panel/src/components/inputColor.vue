<template>
  <div class="colorNameItem">
    色值
    <div class="colorDiv">
      <el-input class="inputValue" @keyup.enter.native="onSubmit" v-model="backgroundColor"></el-input>
      <div class="colorBlock" ref="colorBlock" :style="{backgroundColor:backgroundColor}"></div>
    </div>
  </div>
</template>

<script>
  export default {
    name: "colorDiv",
    data(){
      return{
        backgroundColor:this.bg
      }
    },
    props:["bg"],
    methods:{
      onSubmit(e){
        var value = e.target.value;
        var colorBlock = this.$colorBlock;
        var colorBlock=this.$ref.colorBlock
        colorBlock.style.background=value;
      },

    },
  }
</script>

<style lang="scss">
    @import "../assets/css/mixin";
    .colorNameItem{
        display: flex;
        flex-direction: column;
        width: 600px;
        height: 70px;
        padding: 13px 30px 0px 30px;
        color: #000000;
        font-size: 12px;
        font-family: 'PingFangSC-Regular';
    }
    .colorDiv{
      width: 360px;
      height: 30px;;
      margin-top: 10px;
      display: flex;
      flex-wrap: nowrap;
    }
    .colorDiv > .inputValue > .el-input__inner{
      width: 300px;
      height: 100%;
      font-size: 12px;
      color: #000000;
      font-family: 'PingFangSC-Regular';
      background: #FFFFFF;
      border: 1px solid #D5D5D5;
      border-radius: 3px;
    }
    .colorDiv>.colorBlock{
      width: 40px;
      height: 30px;
      margin-left: 20px;
      border: 1px solid #D5D5D5;
      border-radius: 3px;
    }
</style>



<template>
  <div class="mainTitleItem">
    <div class="titleItem">
      <i class="leftIcon" @click="handlerBack"></i>
      <p class="title">新建基础颜色</p>
    </div>
    <div class="underLine"/>
  </div>
</template>

<script>
  import {mapMutations} from 'vuex'
  export default {
    name: "mainTitleItem",
    methods: {
      handlerBack() {
        this.setEditColorState(false)
      },
      ...mapMutations(
        {'setEditColorState': "SET_EDITCOLOR_STATE"}
      )
    }
  }
</script>

<style lang="scss">
  @import "../assets/css/mixin";

  .mainTitleItem {
    width: 600px;
    height: 42px;
    padding: 13px 30px 0px 30px;
  }

  .titleItem {
    display: flex;

    .leftIcon {
      cursor: pointer;
      margin-top: 2px;
      @include icon(14px, 14px, '../assets/image/ic_return.png');
    }

    .title {
      margin-left: 10px;
      font-size: 12px;
      color: #000000;
      font-family: 'PingFangSC-Regular';
    }
  }

  .underLine {
    height: 1px;
    width: 100%;
    margin-top: 11px;
    border-bottom: 1px solid #D5D5D5;
  }
</style>



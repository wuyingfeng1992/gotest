<style lang="scss">
  @import "../assets/css/mixin";

  .menuContent {
    margin-top: -40px;
    padding: 0 20px;
    height: 506px;
    width: 100%;

    .groupName {
      font-size: 20px;
      color: #434343;
      letter-spacing: 0;
      padding: 30px 20px 20px 10px;
    }

    .colorList {
      display: flex;
      flex-wrap: wrap;
      height: calc(100% - 76px);
      @include showScrollbarY;
    }
  }
</style>
<template>
  <div class="menuContent">
    <!--<editColor :label="data.label"></editColor>-->
    <div v-if="!editColorState" class="groupName">{{data.groupName}}</div>
    <ul v-if="!editColorState" class="colorList">
      <colorItem :item="item" v-for="(item,key) in data.children" :key='key'></colorItem>
    </ul>
    <editColor v-if="editColorState"></editColor>
  </div>
</template>

<script>

  import colorItem from '@components/colorItem'
  import editColor from '@components/editColor'
  // import editThemeColor from '@components/editThemeColor'
  import {mapState} from 'vuex';

  export default {
    name: "menuContent",
    props: ["data"],
    components: {
      colorItem,
      editColor,
    },
    computed: {
      ...mapState([
        "editColorState",
      ])
    }

  }
</script>




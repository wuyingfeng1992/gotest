<style lang="scss">
  @import "../assets/css/mixin";
  .menuSelect{
    .menuSelect-select{
      padding: 10px 10px 0 10px;
      width: $siderWidth;
      background-color: $siderBg;

      .el-input{
        height: 30px;
        .el-input__inner{
          height: 100%;
          background: #FCFCFC;
          border: 1px solid #D5D5D5;
          border-radius: 3px;
          font-size: 12px;
          color:#000;
        }
        .el-input__icon{
          vertical-align: -17px;
        }
        .el-icon-arrow-up.is-reverse:before {
          position: relative;
          top: -10px;
        }

      }

    }
  }
  .el-select-dropdown{
    width:220px !important;
    min-width: auto !important;
    .el-select-dropdown__item{
      font-size: 12px;
      padding: 0 22px;
      height: 26px;
      line-height:26px;
      color:#000;
      position: relative;
      .el-icon-check{
        display: none;

        position: absolute;
        left: 7px;
        top:6.5px;
        color:#000;
        transform: translate(0.8);
        &:before{
          transform: translate(0.8);
        }

      }
      &.selected{
        color:$highlightColor;
        .el-icon-check{
          color:$highlightColor;
          display:inline-block ;
        }
      }

      &:hover{
        background-color: #f0f0f0;
        .el-icon-check{
          color:#000;
          display:inline-block ;
        }
      }
    }
  }

</style>
<template>
  <div class="menuSelect">
    <el-select class="menuSelect-select" v-model="value6" placeholder="请选择"
               @change="menuSelectChange"
          >
      <el-option
        v-for="item in cities"
        :key="item.value"
        :label="item.label"
        :value="item.value"
        >
        <i class="el-icon-check"></i>
        <span class="text">{{ item.label }}</span>
      </el-option>
    </el-select>
    <menuTab :data="getCurrentData"></menuTab>
  </div>

</template>

<script>
  import menuTab from '@components/menuTab'
  export default {
    name: "menuSelect",
    data() {
      return {
        cities: [{
          value: 'Nova',
          label: 'Nova'
        }, {
          value: 'Honor',
          label: 'Honor'
        }],
        value6: '',
        currentData:{
          value: 'Nova',
          label: 'Nova'
        }
      }
    },
    methods:{
      menuSelectChange(data){
        console.log(data)
        let cities=this.cities;
        for(let i=0;i<this.cities.length;i++){
          let item=cities[i];
          if(item.value==data){
            this.currentData=item;
          }
        }

      },
    },
    computed:{
      getCurrentData:function () {
        return this.currentData;
      }
    },
    components:{
      menuTab
    }
  }
</script>


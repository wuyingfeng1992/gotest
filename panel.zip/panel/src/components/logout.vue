<template>
  <div class="logout" title="退出登录" @click="logout">
    <span class="icon-life-buoy"></span>
  </div>
</template>

<script>
  import {mapMutations} from 'vuex';
  import userAxios from '../axios/user.js'
  export default {
    methods:{
      logout:function () {
        console.log('logout');
        window.sessionStorage.setItem('locationHref','edit.html'),
        window.sessionStorage.remove('token');
        window.location.href='login.html';
      }
    }
  }
</script>

<style lang="scss">
  @import "../assets/css/mixin";
  .logout {
    height: 26px;
    margin: 0 5px;
    position: relative;
    width: 25px;
    text-align: center;
    cursor: pointer;
    .icon-life-buoy{

    }
    &:hover{
      .icon-life-buoy{
        color: $mainColor;
      }
    }

  }
</style>

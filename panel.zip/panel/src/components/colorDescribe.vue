<template>
  <div class="colorDescribe">
    描述
    <el-input type="textarea" placeholder="请输入描述..." class="decribe" @keyup.enter.native="onSubmit"></el-input>
    <div class="buttonDiv">
      <el-button class="colorCancle" type="info" plain>取消</el-button>
      <el-button class="colorSave" type="primary">保存</el-button>
    </div>
  </div>
</template>

<script>
  export default {
    name: "colorDescribe",
    methods:{
      //打印输入值
      onSubmit(e){
        var value = e.target.value;
        alert(value);
      }
    }
  }
</script>

<style lang="scss">
    @import "../assets/css/mixin";
    .colorDescribe{
        display: flex;
        flex-direction: column;
        width: 600px;
        height: 70px;
        padding: 13px 30px 12px 30px;
        color: #000000;
        font-size: 12px;
        font-family: 'PingFangSC-Regular';
        .decribe > .el-textarea__inner{
            margin-top: 10px;
            width: 360px;
            height: 120px;
            font-size: 12px;
            color: #000000;
            font-family: 'PingFangSC-Regular';
            background: #FFFFFF;
            border: 1px solid #D5D5D5;
            border-radius: 3px;
        }
      .buttonDiv{
        display: flex;
        margin-top: 20px;
      } 
      .buttonDiv>.colorCancle{
        width: 84px;
        height: 26px;
      } 
      .buttonDiv>.colorSave{
        width: 84px;
        height: 26px;
        margin-left: 16px;
      } 
      .el-button{
        padding:0px;
      }
    }
</style>



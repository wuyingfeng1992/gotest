<template>
  <div class="colorNameItem">
    名称
    <el-input class="nameInput" @keyup.enter.native="onSubmit"></el-input>
  </div>
</template>

<script>
  export default {
    name: "colorNameItem",
    methods:{
      //打印输入值
      onSubmit(e){
        var value = e.target.value;
        alert(value);
      }
    }
  }
</script>

<style lang="scss">
    @import "../assets/css/mixin";
    .colorNameItem{
        display: flex;
        flex-direction: column;
        width: 600px;
        height: 70px;
        padding: 13px 30px 12px 30px;
        color: #000000;
        font-size: 12px;
        font-family: 'PingFangSC-Regular';
        .nameInput > .el-input__inner{
            margin-top: 10px;
            width: 360px;
            height: 30px;
            font-size: 12px;
            color: #000000;
            font-family: 'PingFangSC-Regular';
            background: #FFFFFF;
            border: 1px solid #D5D5D5;
            border-radius: 3px;
        }
    }
</style>



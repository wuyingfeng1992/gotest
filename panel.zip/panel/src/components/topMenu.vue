<template>
  <div class="menuPage">
    <div class="topMenu">
      <div class="leftDiv">
        <i class="leftIcon" v-on:click="handlerBack"> </i>
        <p class="leftTitle">EMUI10.0</p>
      </div>
      <div class="rightDiv">
        <i class="rightIcon1" @click="handlerClick('rightIcon1')"> </i>
        <i class="rightIcon2" @click="handlerClick('rightIcon2')"> </i>
        <i class="rightIcon3" @click="handlerClick('rightIcon3')"> </i>
      </div>
    </div>

  </div>
</template>

<script>

  export default {
    name: "topMenu",
    methods: {
      handlerBack() {
        alert("点击返回");
      },
      handlerClick(params) {
        alert(params);
      }
    },
    components: {
    }
  }
</script>

<style lang="scss">
  @import "../assets/css/mixin";

  .menuPage {
    display: flex;
    flex-direction: column;
    width: 100%;
  }

  .topMenu {
    display: flex;
    background-color: #EEEEEE;
    justify-content: space-between;
    width: 100%;
  }

  .leftDiv {
    display: flex;
    padding-left: 10px;

    .leftIcon {
      margin-top: 9px;
      cursor: pointer;
      @include icon(16px, 11px, '../assets/image/ic_return.png');
    }

    .leftTitle {
      margin-left: 10px;
      margin-top: 5px;
      font-size: 14px;
      font-family: 'PingFangSC-Regular';
      align-content: center;
    }
  }

  $iconMarginLeft: 16px;
  .rightDiv {
    display: flex;
    padding-top: 6px;
    padding-right: 10px;

    .rightIcon1 {
      cursor: pointer;
      @include icon(16px, 14px, '../assets/image/ic_import.png');
      margin-left: $iconMarginLeft;
    }

    .rightIcon2 {
      cursor: pointer;
      @include icon(16px, 14px, '../assets/image/ic_export.png');
      margin-left: $iconMarginLeft;
    }

    .rightIcon3 {
      cursor: pointer;
      @include icon(16px, 16px, '../assets/image/ic_user.png');
      margin-left: $iconMarginLeft;
    }
  }
</style>

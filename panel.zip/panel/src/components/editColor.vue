<template>
  <div class="editColor">
    <mainTitleItem></mainTitleItem>
    <colorNameItem></colorNameItem>
    <inputColor bg='#cc0066'></inputColor>
    <colorDescribe></colorDescribe>
  </div>
</template>

<script>
  import mainTitleItem from '@components/mainTitleItem'
  import colorNameItem from '@components/colorNameItem'
  import inputColor from '@components/inputColor'
  import colorDescribe from '@components/colorDescribe'

  export default {
    name: "editColor",
    components: {
      mainTitleItem,
      colorNameItem,
      inputColor,
      colorDescribe
    }
  }
</script>

<style lang="scss">
  @import "../assets/css/common";
  @import "../assets/css/mixin";

  .editColor {

  }

</style>

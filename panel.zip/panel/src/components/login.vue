<template>
  <div class='register'>
    <div class="form">
      <!--<div class="formHead">{{itemInfo.value}}</div>-->
      <el-form :model="getRuleForm" status-icon :rules="rules" size='small' ref="ruleForm" class="ruleForm">
        <el-form-item prop="debugger">
          <el-input placeholder="账号" v-model.number="getRuleForm.username"></el-input>
        </el-form-item>
        <el-form-item prop="pass">
          <el-input placeholder="密码" type="password" v-model="getRuleForm.pass" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item prop="checkPass" v-if="itemInfo.name=='register'">
          <el-input placeholder="再次输入密码" type="password" v-model="getRuleForm.checkPass"
                    auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item>
          <el-button class='submit' type="primary" @click="submitForm('ruleForm')">{{itemInfo.value}}
          </el-button>
        </el-form-item>
      </el-form>
      <!-- <a class='forget' @click='showForget'>忘记密码？</a>-->
    </div>
    <!--<reset-password @close='close' :visible='resetVisible'></reset-password>-->
  </div>
</template>

<script>
  import userAxios from '@axioser/user.js'

  export default {
    props: ['itemInfo'],
    computed: {
      getRuleForm: function () {
        return this.ruleForm;
      }
    },
    data() {
      const checkname = (rule, value, callback) => {
        if (!value) {
          return callback(new Error('账号不能为空'))
        }
        setTimeout(() => {
          if (`${value}`.length < 3) {
            callback(new Error('至少3位的字符'))
          } else {
            callback()
          }
        }, 100)
      }
      const validatePass = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入密码'))
        } else {
          callback()
        }
      }
      return {
        ruleForm: {
          pass: '',
          checkPass: '',
          username: ''
        },
        rules: {
          //这应该是elment-ui自己绑定的事件
          pass: [
            {validator: validatePass, trigger: 'blur'}
          ],
          checkPass: [
            {validator: validatePass, trigger: 'blur'}
          ],
          username: [
            {validator: checkname, trigger: 'blur'}
          ]
        }
      }
    },
    methods: {
      //重置表单
      /*resetForm(formName) {
          this.$refs[formName].resetFields();
      },*/
      //提交表单
      submitForm: function (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            if (this.itemInfo.name == 'login') {
              this.login(this.ruleForm)
            } else if (this.itemInfo.name == 'register') {
              this.register(this.ruleForm)
            }
          } else {
            console.log('error submit!!');
            return false;
          }
        });

      },
      register: function (ruleForm) {
        var that = this;
       /* userAxios.userRegister(ruleForm)
          .then(({data}) => {
            if (data.success) {
              this.$message({
                type: 'success',
                message: '注册成功注册成功'
              });
              //跳到登录，并登录
              that.$emit('tabChange', 'login');
              setTimeout(function () {
                that.login(ruleForm);
              }, 200)
            } else {
              this.$message({
                type: 'info',
                message: data.error.errorMessage
              });
            }
          })*/
      },
      login: function (ruleForm) {
        /*userAxios.userLogin(ruleForm)
          .then(({data}) => {
            //账号不存在
            if (data.success === false) {
              this.$message({
                type: 'info',
                message: '账号不存在'
              });
              return;
            }
            if (data.success) {
              this.$message({
                type: 'success',
                message: '登录成功'
              });
              //拿到返回的token和username，并存到store
              let token = data.content.token;
              let username = data.content.username;
              this.$store.dispatch('userLogin', token);
              this.$store.dispatch('userName', username);
            //   debugger
              console.log(window.sessionStorage.getItem('token'))
              //跳到目标页
              //this.$router.push('HelloWorld');
              //search跟vue的路由看着很乱
              /!*var search=window.location.search;
              if(search!=='') {
                search=search.indexOf('#')==1?search.substring(1):search;
              }else{
                search='index.html';
              }*!/
              var href=this.$store.state.locationHref||'index.html';
              window.location.href = href;
            }
          });*/
        var href=this.$store.state.locationHref||'index.html';
        window.location.href = href;
      }
    }

  }
</script>

<style scoped lang='sass'>
  .register
    margin-top: 20px
    .form
      width: 100%
      .formHead
        text-align: center
        margin: 10px
        font-size: 20px
      .ruleForm
        text-align: center
        .type
          text-align: left
        .submit
          width: 100%
    .forget
      color: #409eff
      font-size: 15px
      cursor: pointer
</style>

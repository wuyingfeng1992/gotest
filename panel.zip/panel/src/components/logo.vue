<script src="../axios/index.js"></script>
<template>
    <div class="globLogo">
        <!--用a便签，和router-link不一样，link是单页面之间的跳转-->
        <!--<router-link tag="span"  to="./index.html" >
        </router-link>-->
        <a href="index.html" class="logo icon-linkedin icon">

        </a>
    </div>
</template>

<script>
    export default {
        methods:{
            toIndex:function () {
                //这是路由跳转
               // this.$router.push({name:''})
                //window.location.href='./index.html'
            }
        }
    }
</script>
s
<style lang="scss">
    @import "../assets/css/mixin";
    .globLogo{
        display: inline-block;
        width: 36px;
        height: 26px;
        .logo{
            color: $mainColor;
            font-size: 25px;
            cursor: pointer;
        }
    }
</style>

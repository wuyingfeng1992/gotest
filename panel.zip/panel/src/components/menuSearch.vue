<template>
  <div class="menuSearch">
    <el-input
      placeholder="请选择日期"
      suffix-icon="el-icon-search"
      v-model="input2">
    </el-input>
  </div>
</template>

<script>
  export default {
    name: "menuSearch",
    data() {
      return {
        input2: '',
      }
    }
  }
</script>

<style lang="scss">
  .menuSearch{
    .el-input{
      .el-input__inner{
        height: 24px;
        line-height: 24px;
        background-color: #EEEEEE;
        border:none;
      }
      .el-input__icon{
        line-height: 24px;
      }
      .el-input__inner{
        font-size: 12px;
      }

    }
  }
</style>

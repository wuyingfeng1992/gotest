<template>
    <div class="login">
        <div class="loginTab">
            <tabs :tabsInfo="tabsInfo"></tabs>
        </div>

    </div>
</template>

<script>

    import tabs from '@components/tabs'
    export default {
        data() {
            return {
                tabsInfo:[
                    {
                        name:'login',
                        value:'登陆',
                        label:'login'
                    }, {
                        name:'register',
                        value:'注册',
                        label:'login'
                    }
                ]

            }
        },
        components: {
            tabs
        }
    }
</script>

<style lang="scss">
    .login{
        display: flex;
        min-height: 620px;
        .loginTab {
            padding: 20px;
            width: 25%;
            margin: auto;
            padding: 20px;
            border-radius: 5px;
            background: #fff;
            min-width: 350px;
            max-width: 400px;
        }
        .el-tabs__item{
            font-size:18px;
        }
    }

</style>

<style lang="scss">
  @import "../assets/css/common";
  @import "../assets/css/mixin";

  .sourceManage {
    width: $containerWidth;
    .contentWrap{
      height: 506px;
      overflow: hidden;
    }

    .el-header {
      background-color: #B3C0D1;
      color: #333;
      line-height: 60px;
    }

    .el-aside {
      color: #333;
    }

    .custom-tree-node {
      flex: 1;
      display: flex;
      align-items: center;
      justify-content: space-between;
      font-size: 14px;
      padding-right: 8px;
    }

  }

</style>
<template>
  <div class="sourceManage">
    <topMenu></topMenu>
    <div class="contentWrap">
      <menuSelect></menuSelect>
    </div>
  </div>
</template>

<script>
  import topMenu from '@components/topMenu'
  import menuSelect from '@components/menuSelect'

  export default {
    data() {
      return {
      }
    },
    //beforCreate不能拿到methods
    created() {
    },

    computed: {

    },
    methods: {
    },
    components: {
      topMenu,
      menuSelect
    }
  }
</script>




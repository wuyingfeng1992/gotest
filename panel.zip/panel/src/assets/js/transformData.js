var data2={
  "themeColors": [{
    "themeColorId": 3,
    "themeName": "Theme.Emui",
    "attrName": "colorForeground",
    "realValue": "#ff000000",
    "attrValue": "@color/emui_color_fg",
    "remark": "前景色",
    "groupId": 1,
    "groupName": "系统色",
    "attrId": 3,
    "themeId": 14,
    "referenceId": 190,
    "isBase": true,
    "isSapientialTheme": false,
    "isSkinPeeler": false
  },  {
    "themeColorId": 5,
    "themeName": "Theme.Emui",
    "attrName": "colorBackground",
    "realValue": "#ffffffff",
    "attrValue": "@color/emui_color_bg",
    "remark": "背景色",
    "groupId": 1,
    "groupName": "系统色",
    "attrId": 5,
    "themeId": 15,
    "referenceId": 192,
    "isBase": true,
    "isSapientialTheme": false,
    "isSkinPeeler": false
  }],
  "systemColors": [{
    "colorId": 190,
    "colorName": "emui_color_fg",
    "colorValue": "#ff000000",
    "themeId": 14,
    "createTime": "2019-01-11 16:23:28.0",
    "createUser": "admin",
    "lastUpdateTime": "2019-01-11 16:23:28.0",
    "lastUpdateBy": "admin"
  }],
  "groups": [{
    "id": 1,
    "name": "系统色",
    "createTime": "2019-01-11 16:21:14.0",
    "createUser": "admin",
    "lastUpdateTime": "2019-01-11 10:49:42.0"
  }]
}
/*arr:[{
                            "themeName": "Theme.Emui",
                            "themeId": 14,
                            "children": [{
                              "groupId": 1,
                              "groupName": "系统色",
                              "children": [{
                                "themeColorId": 3,
                              }]
                            }]
                          }, {
                            "themeName": "Theme.Emui",
                            "themeId": 15,
                            "children": [{
                              "groupId": 1,
                              "groupName": "系统色",
                              "children": [{
                                "themeColorId": 5,
                              }]
                            }]
                          }]*/
/*keyFormData:{
                            "14": {
                              "1": {
                                "3": {
                                  "themeColorId": 3,
                                  "themeName": "Theme.Emui",
                                  "attrName": "colorForeground",
                                  "realValue": "#ff000000",
                                  "attrValue": "@color/emui_color_fg",
                                  "remark": "前景色",
                                  "groupId": 1,
                                  "groupName": "系统色",
                                  "attrId": 3,
                                  "themeId": 14,
                                  "referenceId": 190,
                                  "isBase": true,
                                  "isSapientialTheme": false,
                                  "isSkinPeeler": false,
                                  "id": 3,
                                  "label": "colorForeground"
                                }
                              },
                              "Info1": {
                                "groupId": 1,
                                "groupName": "系统色",
                                "id": 1,
                                "label": "系统色"
                              }
                            },
                            "Info14": {
                              "themeName": "Theme.Emui",
                              "themeId": 14,
                              "id": 14,
                              "label": "Theme.Emui"
                            }
                          }*/

const dealThemeColorData={

  init(data){
    let result={
      arrFormData:{},
      keyFormData:{}
    }
    let themeColorKeyFormData=this.dealThemeColorItem(data.themeColors);
    result.keyFormData.themeColors=themeColorKeyFormData;
    let themeColorsArrFormData=this.keyToArr(themeColorKeyFormData)
    result.arrFormData.themeColors=themeColorsArrFormData;


    let systemColorKeyFormData=this.dealThemeColorItem(data.systemColors);
    result.keyFormData.systemColors=systemColorKeyFormData;
    let systemColorsArrFormData=this.keyToArr(systemColorKeyFormData)
    result.arrFormData.systemColors=systemColorsArrFormData;
    return result;
  },
  keyToArr:function(data){
    let result=this.keyToArrItem(JSON.parse(JSON.stringify(data)))
    return result;
  },
  keyToArrItem:function(data){
    let result=[];
    for(let key in data){
      if(key.indexOf('Info')!==-1) continue;
      let item=data['Info'+key]
      if(item){
        result.push(item)
        if(data[key]&& data[key].toString()=='[object Object]'){
          item.children=this.keyToArrItem(JSON.parse(JSON.stringify(data[key])))
        }
      }else{
        result.push(data[key]);
      }


    }
    return result;

  },
  dealThemeColorItem:function (colorList) {
    let result={};
    for(let i=0;i<colorList.length;i++){
      let item=colorList[i];
      let colorId=item.colorId;
      let attrId=item.attrId;
      let themeId=item.themeId;
      let groupId=item.groupId;
      let groupName=item.groupName;
      if(!groupId){
        groupId=1;
        groupName='default';

      }

      let attrName=item.attrName;
      let colorName=item.colorName;
      let themeName=item.themeName;

      if(!result[themeId]){
        result[themeId]={}
        result["Info"+themeId]={
          themeName,
          themeId,
          id:themeId,
          label:themeName,
        }
        result[themeId][groupId]={}
        result[themeId]["Info"+groupId]={
          groupId,
          groupName,
          id:groupId,
          label:groupName,

        }
      }
      if(!result[themeId][groupId]){
        result[themeId][groupId]={}
        result[themeId]["Info"+groupId]={
          groupId,
          groupName,
          id:groupId,
          label:groupName,

        }
      }
      if(attrId){
        result[themeId][groupId][attrId]=item;
        result[themeId][groupId][attrId].id=attrId;
        result[themeId][groupId][attrId].label=attrName;
      }else{
        result[themeId][groupId][colorId]=item;
        result[themeId][groupId][colorId].id=colorId;
        result[themeId][groupId][colorId].label=colorName;
      }


    }
    return result
  }

};
export {dealThemeColorData}

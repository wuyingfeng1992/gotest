
var data=`{
    "themeColors": [{
        "themeColorId": 3,
        "themeName": "Theme.Emui",
        "attrName": "colorForeground",
        "realValue": "#ff000000",
        "attrValue": "@color/emui_color_fg",
        "remark": "前景色",
        "groupId": 1,
        "groupName": "系统色",
        "attrId": 3,
        "themeId": 14,
        "referenceId": 190,
        "isBase": true,
        "isSapientialTheme": false,
        "isSkinPeeler": false
      }],
      "systemColors":[{
        "colorId": 190,
        "colorName": "emui_color_fg",
        "colorValue": "#ff000000",
        "createTime": "2019-01-11 16:23:28.0",
        "createUser": "admin",
        "lastUpdateBy": "admin",
        "lastUpdateTime": "2019-01-11 16:23:28.0",
        "themeId": 14
      }],
      "groups": [{
        "id": 1,
        "name": "系统色",
        "createTime": "2019-01-11 16:21:14.0",
        "createUser": "admin",
        "lastUpdateTime": "2019-01-11 10:49:42.0"
      }]
}`
 let json=JSON.parse(data)
export {json} ;

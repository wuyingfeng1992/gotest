export var proxyapi='/proxyapi';
//export const proxyapi='http://uxc-beta.rnd.huawei.com/uxarp/api';
export const wesitePath='http://uxc-beta.rnd.huawei.com/uxarp/api';

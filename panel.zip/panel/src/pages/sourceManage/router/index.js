const sourceManage=r=>require.ensure([],()=>(require('@modules/sourceManage')),'sourceManage');

export default [{
    path:'/',
    name:'sourceManage',
    component:sourceManage,
}]

import {dealThemeColorData} from '@assets/js/transformData'
import {json} from '@/staticData/data.js'
import {
  LOCATION_HREF
,SET_THEMECOLOR
,SET_DEFAULT_CUR_THEMECOLOR
,SET_EDITCOLOR_STATE
} from "@pages/sourceManage/store/mutationType";

import {
  getThemeAttrColorRequest,
} from "@axioser/color";

const state={
  token: window.sessionStorage.getItem('token'),
  themeAttrColor:null,
  editColorState:false,
}

const actions={
  //获取颜色数据
  /*async getThemeAttrColorAction({commit, state}) {
    let res = await getThemeAttrColorRequest({})
    let data = res.data
    if(data.success){
      data=dealThemeColorData.init(JSON.parse(JSON.stringify(data.content)));
      commit('SET_THEMECOLOR', data.arrFormData)
    }

  },*/
  getThemeAttrColorAction({commit, state}) {
    let data = json
    console.log(data)
    data=dealThemeColorData.init(JSON.parse(JSON.stringify(data)));
    commit('SET_THEMECOLOR', data.arrFormData)
  },

};
const mutations={
  [LOCATION_HREF](state,preload){
    window.sessionStorage.setItem('locationHref',preload);
  },
  [SET_THEMECOLOR](state,preload){
    state.themeAttrColor=preload;
  },
  [SET_EDITCOLOR_STATE](state,preload){
    state.editColorState=preload;
  }
}
const getters={
// 得到是否加载中
  getThemeAttrColor: (state) => state.themeAttrColor,
}

export  {state,mutations,actions,getters}

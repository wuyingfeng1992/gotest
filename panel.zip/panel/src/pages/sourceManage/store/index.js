
import {state,mutations,actions,getters} from './store'
export default {
    state:state,
    mutations:mutations,
    actions:actions,
    getters:getters,
}

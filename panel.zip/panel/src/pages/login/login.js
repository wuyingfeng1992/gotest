import Vue from 'Vue'
import VueRouter from 'vue-router'
import routes from './router'
import store from './store'
import login from './login.vue'
import Vuex from "vuex";

import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
Vue.use(ElementUI)
Vue.use(VueRouter)
//要写两遍
//不能写两遍，不然computed的数据没有办法相应action变化的state
Vue.use(Vuex)
const router=new VueRouter({
    routes,
    strict:process.env.NODE_ENV!=='production',
    scrollBehavior(to,from,savedPosition){
      if(savedPosition){
        return savedPosition
      }else{
        if(from.meta.keepAlive){
          from.meta.savePosition=document.body.scrollTop;
        }
        return {x:0,y:to.meta.savePosition||0}
      }
    }
})
let _store=new Vuex.Store(store);
/* eslint-disable no-new */
new Vue({
    el: '#app',
    router,
    store:_store,
    //template: '<App/>',
    render:h=>h(login),
    components: { login }
})

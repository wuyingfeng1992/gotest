import store from './store'
export default {
    state:store.state,
    mutations:store.mutations,
    actions:store.actions
}

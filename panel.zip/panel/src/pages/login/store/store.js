import {LOGIN, LOGOUT, USERNAME} from './mutationType'

//初始化时用sessionStore.getItem('token'),这样子刷新页面就无需重新登录
const state = {
  token: window.sessionStorage.getItem('token'),
  username: '',
  locationHref:window.sessionStorage.getItem('locationHref'),
};

const actions = {
  userLogin({commit}, data) {
    console.log(data);
    commit('LOGIN', data)
  },
  userLogout({commit}) {
    commit('LOGOUT')
  },
  userName({commit}, data) {
    commit('USERNAME', data)
  }
}
//sessionStorage只存在一个会话里
//localStorage不能设置过期时间
//登录只能是一个窗口
const mutations = {
  [LOGIN](state, preload) {
    state.token = preload;
    window.sessionStorage.setItem('token', preload);
  },
  [LOGOUT](state) {
    state.token = null
    window.sessionStorage.removeItem('token');
  },
  [USERNAME](state, preload) {
    //把用户名存起来
    state.username = preload;
    window.sessionStorage.setItem('username', preload);
  }
}

export default {state, mutations, actions}

var edit=require('../login')

const loginPage=r=>require.ensure([],()=>(require('../../../modules/login')),'loginPage');

export default [{
  path:'/',
  name:'loginPage',
  component:loginPage,
}]

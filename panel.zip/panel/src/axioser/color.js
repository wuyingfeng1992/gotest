import instance from './index';
//获取颜色
export const getThemeAttrColorRequest=(data) =>{
    return instance.post('/colorAttr/getThemeAttrColor', data);
}

